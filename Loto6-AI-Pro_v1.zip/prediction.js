// prediction.js (準備中)
